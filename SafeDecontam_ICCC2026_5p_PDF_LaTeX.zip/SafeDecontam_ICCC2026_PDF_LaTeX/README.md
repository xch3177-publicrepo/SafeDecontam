# SafeDecontam five-page manuscript package

Package version: `iccc2026-repro-20260914-v2`. Source commit: `f6023578a5c97f13aa32b1a97f0961434fb21413`.

This compact package contains the compiled five-page PDF, matching LaTeX source, IEEEtran class, figure, build script, version metadata and integrity checker. It does not contain experimental code or data.

From this folder, check the delivered files before rebuilding:

```sh
python3 verify_delivery.py
```

To rebuild, install a LaTeX distribution with `pdflatex` and Poppler's `pdfinfo`, then run:

```sh
bash build.sh
```

The build checks for exactly five pages and rejects LaTeX errors, undefined references and overfull boxes. It writes `SafeDecontam_ICCC2026_camera_ready_5p.pdf`. Rebuilt PDF bytes can depend on the installed LaTeX toolchain; the supplied checksums describe the delivered files.
