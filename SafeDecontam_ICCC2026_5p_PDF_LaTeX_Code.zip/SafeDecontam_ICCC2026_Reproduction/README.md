# SafeDecontam reviewed reproduction delivery

Package version: `iccc2026-repro-20260914-v2`. Source commit: `f6023578a5c97f13aa32b1a97f0961434fb21413`.

`manuscript/` contains the five-page PDF, matching LaTeX, figure and build script. `experiment_source/` contains code, inputs, saved scores, evidence and verification commands. `validation/REVIEW_RESPONSE.md` explains the evidence corrections and remaining access limits.

`validation/availability/` records the subsequent code and data availability statement update; the external-review validation snapshot is preserved separately.

Run `python3 verify_delivery.py` to check file integrity. Then follow `experiment_source/README.md` for computational verification. A checksum check alone is not experimental reproduction.
