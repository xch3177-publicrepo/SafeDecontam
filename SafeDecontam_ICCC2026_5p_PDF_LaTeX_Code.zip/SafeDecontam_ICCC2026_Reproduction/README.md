# SafeDecontam reviewed reproduction delivery

Package version: `iccc2026-repro-20260914`. Source commit: `8d4685c3c0052875f2e8b0774eaed2b64b197ae9`.

`manuscript/` contains the five-page PDF, matching LaTeX, figure and build script. `experiment_source/` contains code, inputs, saved scores, evidence and verification commands. `validation/REVIEW_RESPONSE.md` explains the evidence corrections and remaining access limits.

Run `python3 verify_delivery.py` to check file integrity. Then follow `experiment_source/README.md` for computational verification. A checksum check alone is not experimental reproduction.
